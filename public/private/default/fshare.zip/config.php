<?php 
$config['id'] 		= 'email@fshare_cua_ban';
$config['password'] =  'mat_khau';