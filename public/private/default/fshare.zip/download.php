<?php 
include('start.php');

function _login()
{
	global $html, $curl, $config;
	
	preg_match('#<input type="hidden" value="(.*?)" name="fs_csrf" />#',$html,$fs_csrf);
	
	$data = 'fs_csrf=' . $fs_csrf[1] . '&LoginForm%5Bemail%5D=' . urlencode($config['id']). '&LoginForm%5Bpassword%5D=' . urlencode($config['password']) . '&LoginForm%5BrememberMe%5D=0&LoginForm%5BrememberMe%5D=1&yt0=%C4%90%C4%83ng+nh%E1%BA%ADp';
	$curl->post('https://www.fshare.vn/login',$data);
}

$html = $curl->get('https://www.fshare.vn/file/TM5MQ3VX2T');
if(!preg_match('#<a style="cursor: pointer;color: \#999999;" title="(.*?)"#', $html, $acc))
{
	// chua dang nhap
	_login();
	
}

$link = $curl->get('https://www.fshare.vn/download/index');

echo $link;